/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package programa;

/**
 *
 * @author USUARIO
 */
public class TareaNormal extends Tarea {
    public TareaNormal(String titulo, String descripcion){
        super(titulo, descripcion);
    }
    @Override
    public String prioridad(){
        return "NORMAL";
    }
}
