/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package programa;

/**
 *
 * @author USUARIO
 */
public abstract class Tarea {
    private String titulo;
    private String descripcion;
    private boolean estado;
    
    public Tarea(String titulo, String descripcion){
        this.titulo = titulo;
        this.descripcion = descripcion;
    }
    
    //Getters y setters del titulo
    public String getTitulo(){
        return titulo;
    }
    public void setTitulo(String titulo){
        this.titulo = titulo;
    }
    public String getDescripcion(){
        return descripcion;
    }
    public void setDescripcion(String descripcion){
        this.descripcion = descripcion;
    }
    public boolean getEstado(){
        return estado;
    }
    public void setEstado(boolean estado){
        this.estado = estado;
    }
    
    public abstract String prioridad();
    
    public boolean estaCompletada(){
        return estado;
    }
    public String completada(){
        if(estado == true){
            return "La tarea ha sido completada";
        }
        else{
            return "La tarea NO ha sido completada";
        } 
    }
    
    public void mostrarInfoTarea(){
        System.out.println("Titulo: " + titulo);
        System.out.println("Prioridad: " + prioridad());
        System.out.println("Estado: " + estado);
    }
    @Override
    public String toString(){
        if(estado==true){
        return(getTitulo() + " | " + getDescripcion() + " | " + completada());
        }
        else{
            return(getTitulo() + " | " + getDescripcion() + " | " + completada() + " | " + prioridad());
        }
    }
}
