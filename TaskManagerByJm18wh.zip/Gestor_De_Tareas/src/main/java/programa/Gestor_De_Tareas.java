/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package programa;

/**
 *
 * @author USUARIO
 */
import java.util.ArrayList;

public class Gestor_De_Tareas implements lista {
    private ArrayList<Tarea> tareas = new ArrayList<>();
    
    public void agregarTarea(Tarea e){
        tareas.add(e);             
    }
    
    
    @Override
    public String cargarListaTareas(){
        for(Tarea tarea : tareas){
            return(tareas.size() + "| " +tarea.getTitulo() + ": " + tarea.getDescripcion() + "| Prioridad: " + tarea.prioridad() + "| " + tarea.completada());
        }
        return null;
    }
    public void eliminarTarea(int indice) {
    if (indice >= 0 && indice < tareas.size()) {
        tareas.remove(indice);
    }
    }

    public void limpiarTareas() {
        tareas.clear();
    }

    public int cantidadTareas() {
        return tareas.size();
    }

    public ArrayList<Tarea> getTareas() {
        return new ArrayList<>(tareas);
    }
}
