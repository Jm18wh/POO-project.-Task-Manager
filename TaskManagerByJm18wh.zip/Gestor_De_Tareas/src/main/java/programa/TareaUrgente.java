/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package programa;

/**
 *
 * @author USUARIO
 */
public class TareaUrgente extends Tarea {
    public TareaUrgente(String titulo, String descripcion){
        super(titulo, descripcion);
    }
    @Override
    public String prioridad(){
        return "URGENTE";
    }
}
